//
//  ViewController.swift
//  21.7. Делаем мини-игру
//
//  Created by macbook on 14.04.2024.
//

import UIKit

class ViewController: UIViewController {
    
    //    var customViewElement: MyCustomView = MyCustomView(frame: CGRect(x: 87, y: 400, width: 80, height: 80))
    //
    //    var customViewElement1: MyCustomeView1 = MyCustomeView1(frame: CGRect(x: 150, y: 400, width: 80, height: 80))
    
    
    @IBOutlet weak var viewIndigoOne: UIView!
    
    @IBOutlet weak var viewIndigoSecond: UIView!
    
    @IBOutlet weak var viewGreenOne: UIView!
    
    @IBOutlet weak var viewGreenSecond: UIView!
    
    @IBOutlet weak var viewGrayOne: UIView!
    
    @IBOutlet weak var viewGraySecond: UIView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //        view.addSubview(customViewElement)
        //        view.addSubview(customViewElement1)
        
    }
    
    @IBAction func panActionIndigoOne(_ gesture: UIPanGestureRecognizer) {

        let indigoViewFrameOne = viewIndigoOne.frame
        let indigoViewFrameSecond = viewIndigoSecond.frame


        let gestureTranslation = gesture.translation(in: view)

        guard let gestureView = gesture.view else {

            return
        }

        gestureView.center = CGPoint(x: gestureView.center.x + gestureTranslation.x, y: gestureView.center.y + gestureTranslation.y)

        gesture.setTranslation(.zero, in: view)

        guard gesture.state == .ended else {
            return
        }

        for value in Int(indigoViewFrameSecond.minY)...Int(indigoViewFrameSecond.maxY) {

            if Int(indigoViewFrameOne.origin.y) == value {

                // test
                
                UIView.animate(withDuration: 2, delay: 0.2) {
                    
                    self.viewIndigoSecond.transform = self.viewIndigoSecond.transform.scaledBy(x: 2, y: 2)
                    self.viewIndigoSecond.backgroundColor = .systemMint
                    
                }
                
                viewIndigoOne.isHidden = true
//                viewIndigoSecond.backgroundColor = .systemMint
//                viewIndigoSecond.frame = CGRect(x: gestureView.center.x + gestureTranslation.x, y: gestureView.center.y + gestureTranslation.y, width: viewIndigoSecond.bounds.width + 20, height: viewIndigoSecond.bounds.height + 20)
                
                
                
                // end
                
//                viewIndigoOne.isHidden = true
//                viewIndigoSecond.backgroundColor = .systemMint
//                viewIndigoSecond.frame = CGRect(x: gestureView.center.x + gestureTranslation.x, y: gestureView.center.y + gestureTranslation.y, width: viewIndigoSecond.bounds.width + 20, height: viewIndigoSecond.bounds.height + 20)



            }
        }

    }

      
    

    @IBAction func panActionIndigoSecond(_ gesture: UIPanGestureRecognizer) {
        
        let gestureTranslation = gesture.translation(in: view)
        
        guard let gestureView = gesture.view else {
            
            return
        }
        
        gestureView.center = CGPoint(x: gestureView.center.x + gestureTranslation.x, y: gestureView.center.y + gestureTranslation.y)
        
        gesture.setTranslation(.zero, in: view)
        
        guard gesture.state == .ended else {
            return
        }
        
    }
    
    
    @IBAction func panActionGreenOne(_ gesture: UIPanGestureRecognizer) {

        let greenViewFrameOne = viewGreenOne.frame
        let greenViewFrameSecond = viewGreenSecond.frame

        let gestureTranslation = gesture.translation(in: view)

        guard let gestureView = gesture.view else {

            return
        }

        gestureView.center = CGPoint(x: gestureView.center.x + gestureTranslation.x, y: gestureView.center.y + gestureTranslation.y)

        gesture.setTranslation(.zero, in: view)

        guard gesture.state == .ended else {
            return
        }

        for value in Int(greenViewFrameSecond.minY)...Int(greenViewFrameSecond.maxY) {

            if Int(greenViewFrameOne.origin.y) == value {
                
                UIView.animate(withDuration: 2, delay: 0.2) {
                    
                    self.viewGreenSecond.transform = self.viewGreenSecond.transform.scaledBy(x: 2, y: 2)
                    self.viewGreenSecond.backgroundColor = .red
                    
                }
                

                viewGreenOne.isHidden = true
//                viewGreenSecond.backgroundColor = .red
//                viewGreenSecond.frame = CGRect(x: gestureView.center.x + gestureTranslation.x, y: gestureView.center.y + gestureTranslation.y, width: viewGreenSecond.bounds.width + 20, height: viewGreenSecond.bounds.height + 20)




            }
        }

    }


    @IBAction func panActionGreenSecond(_ gesture: UIPanGestureRecognizer) {

        let gestureTranslation = gesture.translation(in: view)

        guard let gestureView = gesture.view else {

            return
        }

        gestureView.center = CGPoint(x: gestureView.center.x + gestureTranslation.x, y: gestureView.center.y + gestureTranslation.y)

        gesture.setTranslation(.zero, in: view)

        guard gesture.state == .ended else {
            return
        }

    }


    @IBAction func panGrayOne(_ gesture: UIPanGestureRecognizer) {

        let grayViewFrameOne = viewGrayOne.frame
        let grayViewFrameSecond = viewGraySecond.frame

        let gestureTranslation = gesture.translation(in: view)

        guard let gestureView = gesture.view else {

            return
        }

        gestureView.center = CGPoint(x: gestureView.center.x + gestureTranslation.x, y: gestureView.center.y + gestureTranslation.y)

        gesture.setTranslation(.zero, in: view)

        guard gesture.state == .ended else {
            return
        }

        for value in Int(grayViewFrameSecond.minY)...Int(grayViewFrameSecond.maxY) {

            if Int(grayViewFrameOne.origin.y) == value {
                
                UIView.animate(withDuration: 2, delay: 0.2) {
                    
                    self.viewGraySecond.transform = self.viewGraySecond.transform.scaledBy(x: 2, y: 2)
                    self.viewGraySecond.backgroundColor = .blue
                    
                }

                viewGrayOne.isHidden = true
//                viewGraySecond.backgroundColor = .blue
//                viewGraySecond.frame = CGRect(x: gestureView.center.x + gestureTranslation.x, y: gestureView.center.y + gestureTranslation.y, width: viewGraySecond.bounds.width + 20, height: viewGraySecond.bounds.height + 20)


            }


        }
    }


    @IBAction func panGraySecond(_ gesture: UIPanGestureRecognizer) {

        let gestureTranslation = gesture.translation(in: view)

        guard let gestureView = gesture.view else {

            return
        }

        gestureView.center = CGPoint(x: gestureView.center.x + gestureTranslation.x, y: gestureView.center.y + gestureTranslation.y)

        gesture.setTranslation(.zero, in: view)

        guard gesture.state == .ended else {
            return
        }

    }

}
