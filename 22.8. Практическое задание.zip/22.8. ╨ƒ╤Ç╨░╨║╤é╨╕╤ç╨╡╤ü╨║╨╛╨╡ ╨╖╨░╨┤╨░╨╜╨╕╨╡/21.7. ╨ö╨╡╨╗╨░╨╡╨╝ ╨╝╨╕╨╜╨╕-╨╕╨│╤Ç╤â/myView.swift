//
//  myView.swift
//  21.7. Делаем мини-игру
//
//  Created by macbook on 14.04.2024.
//

import UIKit

@IBDesignable

class myView: UIView {
    
    @IBInspectable var roundView: Bool = false {
        
        didSet {
            if roundView {
                layer.cornerRadius = frame.height / 2
            }
        }
        
        
    }
    
    override func prepareForInterfaceBuilder() {
        
        if roundView {
            
            layer.cornerRadius = frame.height / 2
        }
    }
}
