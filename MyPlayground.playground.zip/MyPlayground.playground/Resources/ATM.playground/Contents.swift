
import Foundation

protocol UserData {
    var userName: String { get }    //Имя пользователя
    var userCardId: String { get }   //Номер карты
    var userCardPin: Int { get }       //Пин-код
    var userPhone: String { get }       //Номер телефона
    var userCash: Float { get set }   //Наличные пользователя
    var userBankDeposit: Float { get set }   //Банковский депозит
    var userPhoneBalance: Float { get set }    //Баланс телефона
    var userCardBalance: Float { get set }    //Баланс карты
}

// Actions that the user can choose in the ATM (imitation of buttons)
enum UserActions {
    case pressedRequestBalanceCard
    case pressedRequestBalanceDeposit
    case pressedCashWithdrawal
    case pressedToppingUp
    case pressedToppingUpPhoneAccount(phone: String)
}


// Types of operations selected by the user (confirmation of selection)
enum DescriptionTypesAvailableOperations: String {
    case requestBalanceCard = "Запрос баланса по карте"
    case requestBalanceDeposit = "Запрос баланса по депозиту"
    case cashWithdrawalFromCard = "Снять наличные с карты"
    case cashWithdrawalFromDeposit = "Снять наличные с депозита"
    case toppingUpCardAccount = "Пополнить карту"
    case toppingUpDepositAccount = "Пополнить депозит"
    case toppingUpPhoneAccountFromCard = "Пополнить баланс телефона с карты"
    case toppingUpPhoneAccountFromCash = "Пополнить баланс телефона наличными"
}

// Text errors
enum TextErrors: String {
    case incorrectCard = "Эта карта не зарегистрирована в банке"
    case incorrectPin = "Введен неверный PIN-код"
    case insufficientFunds = "На счете не достаточно средств"
    case incorrectNumberPhone = "Не корректный номер телефона"
}


// The protocol for working with the bank provides access to the data of a user registered with the bank
protocol BankApi {
    func showUserCardBalance()
    func showUserDepositBalance()
    func showUserToppedUpMobilePhoneCash(cash: Float)
    func showUserToppedUpMobilePhoneCard(card: Float)
    func showWithdrawalCard(cash: Float)
    func showWithdrawalDeposit(cash: Float)
    func showTopUpCard(cash: Float)
    func showTopUpDeposit(cash: Float)
    func showError(error: TextErrors)

    func checkUserPhone(phone: String) -> Bool
    func checkMaxUserCash(cash: Float) -> Bool
    func checkMaxUserCard(withdraw: Float) -> Bool
    func checkMaxUserDeposit(withdraw: Float) -> Bool
    func checkCurrentUser(userCardId: String, userCardPin: Int) -> Bool

    mutating func topUpPhoneBalanceCash(pay: Float)
    mutating func topUpPhoneBalanceCard(pay: Float)
    mutating func getCashFromDeposit(cash: Float)
    mutating func getCashFromCard(cash: Float)
    mutating func putCashDeposit(topUp: Float)
    mutating func putCashCard(topUp: Float)
}


// Payment method/replenishment in cash, by card or via deposit
enum PaymentMethod {
    case cash(amount:Float)
    case deposit(amount:Float)
    case card(amount:Float)

}


// User
struct User: UserData {
    var userName: String
    var userCardId: String
    var userCardPin: Int
    var userPhone: String
    var userCash: Float
    var userBankDeposit: Float
    var userPhoneBalance: Float
    var userCardBalance: Float
}

// Bank
final class Bank: BankApi {

    var customerBase = [String: User]()
    var userId = ""

    func addNewCustomer(user: User) {
        if customerBase[user.userCardId] == nil {
            customerBase[user.userCardId] = user
        }
    }

    func showUserCardBalance() {
        guard let user = customerBase[userId] else { return }
        let report = "Баланс Вашей карты составляет - \(user.userCardBalance) руб. \n"
        print(report)
    }

    func showUserDepositBalance() {
        guard let user = customerBase[userId] else { return }
        let report = "Баланс Вашего депозита составляет - \(user.userBankDeposit) руб. \n"
        print(report)
    }

    func showUserToppedUpMobilePhoneCash(cash: Float) {
        guard let user = customerBase[userId] else { return }
        let report = """
                        Вы пополнили баланс телефона на сумму \(cash) руб.
                        У Вас осталось \(user.userCash) руб. наличными
                        Баланс Вашего телефона составляет \(user.userPhoneBalance) \n
                        """
        print(report)
    }

    func showUserToppedUpMobilePhoneCard(card: Float) {
        guard let user = customerBase[userId] else { return }
        let report = """
                        Вы пополнили баланс телефона на сумму \(card) руб.
                        На Вашей карте осталось \(user.userCardBalance) руб.
                        Баланс Вашего телефона составляет \(user.userPhoneBalance) \n
                        """
        print(report)
    }

    func showWithdrawalCard(cash: Float) {
        guard let user = customerBase[userId] else { return }
        let report = """
                        Вы сняли с Вашей карты сумму в размере \(cash) руб.
                        На Вашей карте осталось \(user.userCardBalance) руб.
                        Сумма наличных сейчас составляет \(user.userCash) руб. \n
                        """
        print(report)
    }

    func showWithdrawalDeposit(cash: Float) {
        guard let user = customerBase[userId] else { return }
        let report = """
                        Вы сняли с Вашего депозита сумму в размере \(cash) руб.
                        На Вашем депозите осталось \(user.userBankDeposit) руб.
                        Сумма наличных сейчас составляет \(user.userCash) руб. \n
                        """
        print(report)
    }

    func showTopUpCard(cash: Float) {
        guard let user = customerBase[userId] else { return }
        let report = """
                        Вы пополнили баланс Вашей карты на сумму \(cash) руб.
                        Баланс Вашей карты составляет \(user.userCardBalance) руб.
                        Сумма наличных сейчас составляет \(user.userCash) руб. \n
                        """
        print(report)
    }

    func showTopUpDeposit(cash: Float) {
        guard let user = customerBase[userId] else { return }
        let report = """
                        Вы пополнили баланс Вашего депозита на сумму \(cash) руб.
                        На Вашем депозите сейчас \(user.userBankDeposit) руб.
                        Сумма наличных сейчас составляет \(user.userCash) руб. \n
                        """
        print(report)
    }

    func showError(error: TextErrors) {
        let report = """
                        Уважаемый \(customerBase[userId]!.userName)!
                        \(error.rawValue). \n
                        """
        print(report)
    }

    func checkUserPhone(phone: String) -> Bool {
        guard let user = customerBase[userId] else { return false }
        if phone == user.userPhone {
            return true
        }
        return false
    }

    func checkMaxUserCash(cash: Float) -> Bool {
        guard let user = customerBase[userId] else { return false}
        if cash <= user.userCash {
            return true
        }
        return false
    }

    func checkMaxUserCard(withdraw: Float) -> Bool {
        guard let user = customerBase[userId] else { return false }
        if withdraw <= user.userCardBalance {
            return true
        }
        return false
    }

    func checkMaxUserDeposit(withdraw: Float) -> Bool {
        guard let user = customerBase[userId] else { return false }
        if withdraw <= user.userBankDeposit {
            return true
        }
        return false
    }

    func checkCurrentUser(userCardId: String, userCardPin: Int) -> Bool {
        guard let user = customerBase[userId] else {
            print("\(TextErrors.incorrectCard.rawValue)\n");
            return false
        }

        userId = userCardId

        if customerBase[userCardId]?.userCardPin == userCardPin {
            print("Здравствуйте, \(user.userName)!\n")
            return true
        } else {
            showError(error: .incorrectPin)
        }
        return false
    }

    func topUpPhoneBalanceCash(pay: Float) {
        customerBase[userId]?.userCash -= pay
        customerBase[userId]?.userPhoneBalance += pay
    }

    func topUpPhoneBalanceCard(pay: Float) {
        customerBase[userId]?.userCardBalance -= pay
        customerBase[userId]?.userPhoneBalance += pay
    }

    func getCashFromDeposit(cash: Float) {
        customerBase[userId]?.userBankDeposit -= cash
        customerBase[userId]?.userCash += cash
    }

    func getCashFromCard(cash: Float) {
        customerBase[userId]?.userCardBalance -= cash
        customerBase[userId]?.userCash += cash
    }

    func putCashDeposit(topUp: Float) {
        customerBase[userId]?.userCash -= topUp
        customerBase[userId]?.userBankDeposit += topUp
    }

    func putCashCard(topUp: Float) {
        customerBase[userId]?.userCash -= topUp
        customerBase[userId]?.userCardBalance += topUp
    }
}


// ATM
class ATM {
    private let userCardId: String
    private let userCardPin: Int
    private var someBank: BankApi
    private let action: UserActions
    private let paymentMethod: PaymentMethod?
    private var isUser: Bool?

    init(
        userCardId: String,
        userCardPin: Int,
        someBank: BankApi,
        action: UserActions,
        paymentMethod: PaymentMethod? = nil
    ) {
        self.userCardId = userCardId
        self.userCardPin = userCardPin
        self.someBank = someBank
        self.action = action
        self.paymentMethod = paymentMethod

        sendUserDataToBank(userCardId: userCardId, userCardPin: userCardPin)
    }

    public final func sendUserDataToBank(userCardId: String, userCardPin: Int) {
        isUser = someBank.checkCurrentUser(userCardId: userCardId, userCardPin: userCardPin)
    }

    func ATMOperation(actions: UserActions, payment: PaymentMethod?) {
        guard isUser! else { return }

        switch actions {
        case .pressedRequestBalanceCard:
            print(DescriptionTypesAvailableOperations.requestBalanceCard.rawValue)
            someBank.showUserCardBalance()

        case .pressedRequestBalanceDeposit:
            print(DescriptionTypesAvailableOperations.requestBalanceDeposit.rawValue)
            someBank.showUserDepositBalance()

        case .pressedCashWithdrawal:
            if let payment = payment {
                switch payment {
                case let .card(amount: money):
                    print(DescriptionTypesAvailableOperations.cashWithdrawalFromCard.rawValue)
                    if someBank.checkMaxUserCard(withdraw: money) {
                        someBank.getCashFromCard(cash: money)
                        someBank.showWithdrawalCard(cash: money)
                    } else {
                        someBank.showError(error: .insufficientFunds)
                    }
                case let .deposit(amount: money):
                    print(DescriptionTypesAvailableOperations.cashWithdrawalFromDeposit.rawValue)
                    if someBank.checkMaxUserDeposit(withdraw: money) {
                        someBank.getCashFromDeposit(cash: money)
                        someBank.showWithdrawalDeposit(cash: money)
                    } else {
                        someBank.showError(error: .insufficientFunds)
                    }
                default:
                    break
                }
            }

        case .pressedToppingUp:
            if let payment = payment {
                switch payment {
                case let .card(amount: cash):
                    print(DescriptionTypesAvailableOperations.toppingUpCardAccount.rawValue)
                    if someBank.checkMaxUserCash(cash: cash) {
                        someBank.putCashCard(topUp: cash)
                        someBank.showTopUpCard(cash: cash)
                    } else {
                        someBank.showError(error: .insufficientFunds)
                    }
                case let .deposit(amount: cash):
                    print(DescriptionTypesAvailableOperations.toppingUpDepositAccount.rawValue)
                    if someBank.checkMaxUserCash(cash: cash) {
                        someBank.putCashDeposit(topUp: cash)
                        someBank.showTopUpDeposit(cash: cash)
                    } else {
                        someBank.showError(error: .insufficientFunds)
                    }
                default:
                    break
                }
            }

        case let .pressedToppingUpPhoneAccount(phone: number):
            if someBank.checkUserPhone(phone: number) {
                if let payment = payment {

                    switch payment {
                    case let .card(amount: amount):
                        print(DescriptionTypesAvailableOperations.toppingUpPhoneAccountFromCard.rawValue)
                        if someBank.checkMaxUserCard(withdraw: amount) {
                            someBank.topUpPhoneBalanceCard(pay: amount)
                            someBank.showUserToppedUpMobilePhoneCard(card: amount)
                        } else {
                            someBank.showError(error: .insufficientFunds)
                        }
                    case let .cash(amount: amount):
                        print(DescriptionTypesAvailableOperations.toppingUpPhoneAccountFromCash.rawValue)
                        if someBank.checkMaxUserCash(cash: amount) {
                            someBank.topUpPhoneBalanceCash(pay: amount)
                            someBank.showUserToppedUpMobilePhoneCash(cash: amount)
                        } else {
                            someBank.showError(error: .insufficientFunds)
                        }
                    default:
                        break
                    }

                }
            } else {
                someBank.showError(error: .incorrectNumberPhone)
            }
        }
    }
}


// Create user
var ivan = User(
    userName: "Ivan Tarasenko",
    userCardId: "3456 3476 8798 6709",
    userCardPin: 1234,
    userPhone: "+79803910477",
    userCash: 500,
    userBankDeposit: 1000,
    userPhoneBalance: 100,
    userCardBalance: 5000
)
var oleg = User(
    userName: "Oleg Tinkoff",
    userCardId: "6576 3443 8787 3844",
    userCardPin: 4321,
    userPhone: "+799934343243",
    userCash: 0.0,
    userBankDeposit: 0.0,
    userPhoneBalance: 0.0,
    userCardBalance: 0.0
)
var natalya = User(
    userName: "Natalya Valuyskay",
    userCardId: "7686 3456 9865 3468",
    userCardPin: 0000,
    userPhone: "+79103456878",
    userCash: 102_345.65,
    userBankDeposit: 345.7,
    userPhoneBalance: 1002.4,
    userCardBalance: 56_657.5
)


// Add customer base
let bank = Bank()
bank.addNewCustomer(user: ivan)
bank.addNewCustomer(user: oleg)
bank.addNewCustomer(user: natalya)

// The customer came to the ATM inserted the card and entered the PIN
let atmSessionIvan = ATM(
    userCardId: ivan.userCardId,
    userCardPin: ivan.userCardPin,
    someBank: bank,
    action: .pressedRequestBalanceCard
)


// Requesting a balance on the card and on a bank deposit
atmSessionIvan.ATMOperation(actions: .pressedRequestBalanceDeposit, payment: .none)
atmSessionIvan.ATMOperation(actions: .pressedRequestBalanceCard, payment: .none)

// Cash withdrawal from the card and from the bank deposit
atmSessionIvan.ATMOperation(actions: .pressedCashWithdrawal, payment: .card(amount: 100))
atmSessionIvan.ATMOperation(actions: .pressedCashWithdrawal, payment: .deposit(amount: 500))

// Replenishment of the card and bank deposit in cash
atmSessionIvan.ATMOperation(actions: .pressedToppingUp, payment: .card(amount: 300))
atmSessionIvan.ATMOperation(actions: .pressedToppingUp, payment: .deposit(amount: 200))

// Topping up your phone balance in cash and with a card
atmSessionIvan.ATMOperation(actions: .pressedToppingUpPhoneAccount(phone: ivan.userPhone), payment: .card(amount: 50))
atmSessionIvan.ATMOperation(actions: .pressedToppingUpPhoneAccount(phone: ivan.userPhone), payment: .cash(amount: 100))


// Checking the validity of the card
let atmSessionOleg1 = ATM(
    userCardId: "0000 0000 0000 0000",
    userCardPin: 000,
    someBank: bank,
    action: .pressedToppingUp
)

// Checking the validity of the PIN
let atmSessionOleg2 = ATM(
    userCardId: oleg.userCardId,
    userCardPin: 0000,
    someBank: bank,
    action: .pressedCashWithdrawal
)

let atmSessionOleg3 = ATM(
    userCardId: oleg.userCardId,
    userCardPin: oleg.userCardPin,
    someBank: bank,
    action: .pressedRequestBalanceCard
)

// Checking cash withdrawal
atmSessionOleg3.ATMOperation(actions: .pressedCashWithdrawal, payment: .card(amount: 100))
atmSessionOleg3.ATMOperation(actions: .pressedCashWithdrawal, payment: .deposit(amount: 200))

// Checking account replenishment
atmSessionOleg3.ATMOperation(actions: .pressedToppingUp, payment: .card(amount: 200))
atmSessionOleg3.ATMOperation(actions: .pressedToppingUp, payment: .deposit(amount: 100))

// Checking the entered phone number
atmSessionOleg3.ATMOperation(actions: .pressedToppingUpPhoneAccount(phone: "8 475 45 23"), payment: .card(amount: 100))
atmSessionOleg3.ATMOperation(actions: .pressedToppingUpPhoneAccount(phone: "+7 234 65 34"), payment: .deposit(amount: 50))

// Checking the replenishment of the phone number
atmSessionOleg3.ATMOperation(actions: .pressedToppingUpPhoneAccount(phone: oleg.userPhone), payment: .cash(amount: 250))
atmSessionOleg3.ATMOperation(actions: .pressedToppingUpPhoneAccount(phone: oleg.userPhone), payment: .card(amount: 100))
