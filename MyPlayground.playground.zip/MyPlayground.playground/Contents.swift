
protocol UserDate {
    
    var userName: String {get} // Имя пользователя
    var userCardId: String {get} // Номер карты
    var userCardPin: Int {get} // пин код от карты
    var userPhone: String {get} // Номер телефона пользователя
    var userCash: Float {get set} // Наличные деньги пользователя
    var userBankDeposit: Float {get set}   //Банковский депозит
    var userPhoneBalance: Float {get set}     //Баланс телефона
    var userCardBalance: Float {get set}    //Баланс карты
}

// Действия, которые пользователь может выбирать в банкомате (имитация кнопок)

enum UserActions {
    
    case userRequestBalanceCard // Запрос баланса карты
    case userRequestBalanceDeposit // Зап. бал. депозита
    case userCashWithdrawal // Снять наличные
    case userToppingUp // Пополнить
    case userToppingUpPhoneAccount(phone: String) // Пополнить тел.
    
}

// Виды операций, выбранных пользователем (подтверждение выбора)

enum DescriptionTypesAvailableOperations: String {

    case requestBalanceCard = "Запрос баланса по карте"
    case requestBalanceDeposit = "Запрос баланса по депозиту"
    case cashWithdrawalFromCard = "Снять наличные с карты"
    case cashWithdrawalFromDeposit = "Снять наличные с депозита"
    case toppingUpCardAccount = "Пополнить карту"
    case toppingUpDepositAccount = "Пополнить депозит"
    case toppingUpPhoneAccountFromCard = "Пополнить баланс телефона с карты"
    case toppingUpPhoneAccountFromCash = "Пополнить баланс телефона наличными"
    
}

// Тексты ошибок

enum TextErrors: String {
    
    case errorCardNumber = " Неверно указан номер карты "
    case errorCardPin = " Неверно указан пароль "
    case errorNotMoney = " Недостаточно средств "
    case errorNumberPhone = " Неверно указан телефон "
}

// Протокол по работе с банком предоставляет доступ к данным пользователя зарегистрированного в банке

protocol BankApi {
    
    func showUserCardBalance() // Показать баланс карты
    func showUserDepositBalance() // Показать баланс депозита
    func showUserToppedUpMobilePhoneCash(cash: Float) // Пополнить баланс телефона наличными
    func showUserToppedUpMobilePhoneCard(card: Float) // Пополнить баланс телефона картой
    func showWithdrawalCard(cash: Float) // Снятие с карты
    func showWithdrawalDeposit(cash: Float) // Снятие с депозита
    func showTopUpCard(cash: Float) // Пополнение карты
    func showTopUpDeposit(cash: Float) // Пополнение депозита
    func showError(error: TextErrors)
    
    func checkUserPhone(phone: String) -> Bool
    func checkMaxUserCash(cash: Float) -> Bool
    func checkMaxUserCard(withdraw: Float) -> Bool
    func checkMaxUserDeposit(withdraw: Float) -> Bool
    func checkCurrentUser(userCardId: String, userCardPin: Int) -> Bool
    
    mutating func topUpPhoneBalanceCash(pay: Float)
    mutating func topUpPhoneBalanceCard(pay: Float)
    mutating func getCashFromDeposit(cash: Float)
    mutating func getCashFromCard(cash: Float)
    mutating func putCashDeposit(topUp: Float)
    mutating func putCashCard(topUp: Float)
}

// Способ оплаты/пополнения наличными, картой или через депозит

enum PaymentMethod {
    case cash(amount:Float)
    case deposit(amount:Float)
    case card(amount:Float)
}

// Пользователь

struct User: UserDate {
    
    var userName: String
    var userCardId: String
    var userCardPin: Int
    var userPhone: String
    var userCash: Float
    var userBankDeposit: Float
    var userPhoneBalance: Float
    var userCardBalance: Float
    
}

// Банк

final class Bank: BankApi {
    
    var customerBase = [String: User]()
    var userId = ""
    
    func addNewCustomer(user: User) {
        if customerBase[user.userCardId] == nil {
            customerBase[user.userCardId] = user
        }
    }
    
    func showUserCardBalance() {
        
        guard let user = customerBase[userId]
        else { return }
        let report = " Баланс карты составляет - \(user.userCardBalance) руб. "
        print(report)
    }
    
    func showUserDepositBalance() {
        
        guard let user = customerBase[userId]
        else { return }
        let report = " Баланс депозита составляет - \(user.userBankDeposit) руб. "
        print(report)
    }
    
    func showUserToppedUpMobilePhoneCash(cash: Float) {
        
        guard let user = customerBase[userId]
        else { return }
        let report = " Вы пополнили баланс телефона на сумму \(cash) руб. У вас осталось наличных \(user.userCash) руб. Баланс телефона составляет \(user.userPhoneBalance) руб."
        print(report)
    }
    
    func showUserToppedUpMobilePhoneCard(card: Float) {
        
        guard let user = customerBase[userId]
        else { return }
        let report = " Вы пополнили баланс телефона на сумму \(card) руб. На карте осталось \(user.userCardBalance) руб. Баланс телефона составляет \(user.userPhoneBalance) руб."
        print(report)
    }
    
    func showWithdrawalCard(cash: Float) {
        
        guard let user = customerBase[userId]
        else { return }
        let report = " Вы сняли с карты \(cash) руб. На карте соталось \(user.userCardBalance) руб. Сумма наличных \(user.userCash) рую. "
        print(report)
    }
    
    func showWithdrawalDeposit(cash: Float) {
        
        guard let user = customerBase[userId]
        else { return }
        let report = " Вы сняли с депозита \(cash) руб. На депозите соталось \(user.userBankDeposit) руб. Сумма наличных \(user.userCash) рую. "
        print(report)
        
    }
    
    func showTopUpCard(cash: Float) {
        
        guard let user = customerBase[userId]
        else { return }
        let report = " Вы пополнили баланс карты на \(cash) руб. Баланс карты составляет \(user.userCardBalance) руб. Сумма наличных \(user.userCash) руб. "
        print(report)
        
    }
    
    func showTopUpDeposit(cash: Float) {
        
        guard let user = customerBase[userId]
        else { return }
        let report = " Вы пополнили баланс депозита на \(cash) руб. Баланс депозита составляет \(user.userBankDeposit) руб. Сумма наличных \(user.userCash) руб. "
        print(report)
        
    }
    
    func showError(error: TextErrors) {
        
        let report = " Уважаемны \(customerBase[userId]!.userName)! \(error.rawValue) "
        print(report)
    }
    
    func checkUserPhone(phone: String) -> Bool {
        
        guard let user = customerBase[userId]
        else { return false }
        if phone == user.userPhone {
            return true
        }
        else { return false }
        
    }
    
    func checkMaxUserCash(cash: Float) -> Bool {
        
        guard let user = customerBase[userId]
        else { return false }
        if cash <= user.userCash {
            return true
        }
        else { return false }
        
    }
    
    func checkMaxUserCard(withdraw: Float) -> Bool {
        
        guard let user = customerBase[userId]
        else { return false }
        if withdraw <= user.userCardBalance {
            return true
        }
        else { return false }
        
    }
    
    func checkMaxUserDeposit(withdraw: Float) -> Bool {
        
        guard let user = customerBase[userId]
        else { return false }
        if withdraw <= user.userBankDeposit {
            return true
        }
        else { return false }
        
    }
    
    func checkCurrentUser(userCardId: String, userCardPin: Int) -> Bool {
        
        userId = userCardId
        
        guard let user = customerBase[userId]
        else {
            print(" \(TextErrors.errorCardNumber.rawValue) ")
            return false
        }
        
        
        if customerBase[userCardId]?.userCardPin == userCardPin {
            print("Здравствуйте \(user.userName)!")
            return true
            
        }else{
            showError(error: .errorCardPin)
        }
        return false
        
    }
    
    func topUpPhoneBalanceCash(pay: Float) {
        
        customerBase[userId]?.userCash -= pay
        customerBase[userId]?.userPhoneBalance += pay
    }
    
    func topUpPhoneBalanceCard(pay: Float) {
        customerBase[userId]?.userCardBalance -= pay
        customerBase[userId]?.userPhoneBalance += pay
    }

    func getCashFromDeposit(cash: Float) {
        customerBase[userId]?.userBankDeposit -= cash
        customerBase[userId]?.userCash += cash
    }

    func getCashFromCard(cash: Float) {
        customerBase[userId]?.userCardBalance -= cash
        customerBase[userId]?.userCash += cash
    }

    func putCashDeposit(topUp: Float) {
        customerBase[userId]?.userCash -= topUp
        customerBase[userId]?.userBankDeposit += topUp
    }

    func putCashCard(topUp: Float) {
        customerBase[userId]?.userCash -= topUp
        customerBase[userId]?.userCardBalance += topUp
    }
}


// Банкомат, с которым мы работаем

final class ATM {
    private let userCardId: String
    private let userCardPin: Int
    private var someBank: BankApi
    private let action: UserActions
    private let paymentMethod: PaymentMethod?
    private var isUser: Bool?

    init(
        userCardId: String,
        userCardPin: Int,
        someBank: BankApi,
        action: UserActions,
        paymentMethod: PaymentMethod? = nil
    ) {
        self.userCardId = userCardId
        self.userCardPin = userCardPin
        self.someBank = someBank
        self.action = action
        self.paymentMethod = paymentMethod

        sendUserDataToBank(userCardId: userCardId, userCardPin: userCardPin)
    }

    public final func sendUserDataToBank(userCardId: String, userCardPin: Int) {
        isUser = someBank.checkCurrentUser(userCardId: userCardId, userCardPin: userCardPin)
    }

    func ATMOperation(actions: UserActions, payment: PaymentMethod?) {
        guard isUser! else { return }

        switch actions {
        case .userRequestBalanceCard:
            requestBalanceCard()

        case .userRequestBalanceDeposit:
            requestBalanceDeposit()

        case .userCashWithdrawal:
            cashWithdrawal(payment: payment)

        case .userToppingUp:
            toppingUp(payment: payment)

        case let .userToppingUpPhoneAccount(phone: number):
            toppingUpPhoneAccount(payment: payment, number: number)
        }
    }
    
    // Запрос даланса карты
    func requestBalanceCard() {
        print(DescriptionTypesAvailableOperations.requestBalanceCard.rawValue)
        someBank.showUserCardBalance()
    }
    
    // Запрос баланса депазита
    func requestBalanceDeposit() {
        print(DescriptionTypesAvailableOperations.requestBalanceDeposit.rawValue)
        someBank.showUserDepositBalance()
    }
    
    // Снатие наличных
    func cashWithdrawal(payment: PaymentMethod?) {
        if let payment = payment {
            
            switch payment {
            case let .card(amount: money):
                print(DescriptionTypesAvailableOperations.cashWithdrawalFromCard.rawValue)
                if someBank.checkMaxUserCard(withdraw: money) {
                    someBank.getCashFromCard(cash: money)
                    someBank.showWithdrawalCard(cash: money)
                } else {
                    someBank.showError(error: .errorNotMoney)
                }
                
            case let .deposit(amount: money):
                print(DescriptionTypesAvailableOperations.cashWithdrawalFromDeposit.rawValue)
                if someBank.checkMaxUserDeposit(withdraw: money) {
                    someBank.getCashFromDeposit(cash: money)
                    someBank.showWithdrawalDeposit(cash: money)
                } else {
                    someBank.showError(error: .errorNotMoney)
                }
            default:
                break
            }
        }
    }
    
    // Пополнение
    func toppingUp(payment: PaymentMethod?) {
        if let payment = payment {
            
            switch payment {
            case let .card(amount: cash):
                
                print(DescriptionTypesAvailableOperations.toppingUpCardAccount.rawValue)
                if someBank.checkMaxUserCash(cash: cash) {
                    someBank.putCashCard(topUp: cash)
                    someBank.showTopUpCard(cash: cash)
                } else {
                    someBank.showError(error: .errorNotMoney)
                }
                
            case let .deposit(amount: cash):
                print(DescriptionTypesAvailableOperations.toppingUpDepositAccount.rawValue)
                if someBank.checkMaxUserCash(cash: cash) {
                    someBank.putCashDeposit(topUp: cash)
                    someBank.showTopUpDeposit(cash: cash)
                } else {
                    someBank.showError(error: .errorNotMoney)
                }
            default:
                break
            }
        }
    }
    
    // Пополнение номера телефона
    func toppingUpPhoneAccount(payment: PaymentMethod?, number: String) {
        if someBank.checkUserPhone(phone: number) {
            if let payment = payment {

                switch payment {
                case let .card(amount: amount):
                    print(DescriptionTypesAvailableOperations.toppingUpPhoneAccountFromCard.rawValue)
                    if someBank.checkMaxUserCard(withdraw: amount) {
                        someBank.topUpPhoneBalanceCard(pay: amount)
                        someBank.showUserToppedUpMobilePhoneCard(card: amount)
                    } else {
                        someBank.showError(error: .errorNotMoney)
                    }
                    
                case let .cash(amount: amount):
                    print(DescriptionTypesAvailableOperations.toppingUpPhoneAccountFromCash.rawValue)
                    if someBank.checkMaxUserCash(cash: amount) {
                        someBank.topUpPhoneBalanceCash(pay: amount)
                        someBank.showUserToppedUpMobilePhoneCash(cash: amount)
                    } else {
                        someBank.showError(error: .errorNotMoney)
                    }
                default:
                    break
                }

            }
        } else {
            someBank.showError(error: .errorNumberPhone)
        }
    }
}


// Создаем пользователя

var maksim = User(
    userName: "Maksim Bondin",
    userCardId: "1111 1111 1111 1111",
    userCardPin: 1111,
    userPhone: "+79273919860",
    userCash: 70_000.77,
    userBankDeposit: 777.0,
    userPhoneBalance: 1200.8,
    userCardBalance: 48_358.9
)

// Добавляем пользователя в базу данных банка
let bank = Bank()
    
bank.addNewCustomer(user: maksim)


 //Клиент подошел к банкомату вставил карту и ввел PIN-код
//let atmSessionMaksim = ATM(
//    userCardId: maksim.userCardId,
//    userCardPin: maksim.userCardPin,
//    someBank: bank,
//    action: .userRequestBalanceCard
//)
//
//
//// Запрос остатка средств на карте и на банковском депозите
//atmSessionMaksim.ATMOperation(actions: .userRequestBalanceDeposit, payment: .none)
//atmSessionMaksim.ATMOperation(actions: .userRequestBalanceCard, payment: .none)
//
//// Снятие наличных с карты и с банковского вклада
//atmSessionMaksim.ATMOperation(actions: .userCashWithdrawal, payment: .card(amount: 300))
//atmSessionMaksim.ATMOperation(actions: .userCashWithdrawal, payment: .deposit(amount: 1200))
//
//// Пополнение карты и банковского вклада наличными
//atmSessionMaksim.ATMOperation(actions: .userToppingUp, payment: .card(amount: 600))
//atmSessionMaksim.ATMOperation(actions: .userToppingUp, payment: .deposit(amount: 50))
//
//// Пополните баланс своего телефона наличными и с помощью карты
//atmSessionMaksim.ATMOperation(actions: .userToppingUpPhoneAccount(phone: maksim.userPhone), payment: .card(amount: 400))
//atmSessionMaksim.ATMOperation(actions: .userToppingUpPhoneAccount(phone: maksim.userPhone), payment: .cash(amount: 200))


//// Проверка карты
let atmSessionMaksim1 = ATM(
    userCardId: "1111 1111 1111 1111",
    userCardPin: 1111,
    someBank: bank,
    action: .userToppingUp
)

////// Проверка Pin кода
let atmSessionMaksim2 = ATM(
    userCardId: maksim.userCardId,
    userCardPin: 1111,
    someBank: bank,
    action: .userCashWithdrawal
)

let atmSessionMaksim3 = ATM(
    userCardId: maksim.userCardId,
    userCardPin: maksim.userCardPin,
    someBank: bank,
    action: .userRequestBalanceCard
)

////// Проверка снятия наличных
atmSessionMaksim1.ATMOperation(actions: .userCashWithdrawal, payment: .card(amount: 300))
atmSessionMaksim1.ATMOperation(actions: .userCashWithdrawal, payment: .deposit(amount: 1200))

////// Пополнение текущего счета
atmSessionMaksim1.ATMOperation(actions: .userToppingUp, payment: .card(amount: 600))
atmSessionMaksim1.ATMOperation(actions: .userToppingUp, payment: .deposit(amount: 50))

////// Проверка введенного номера телефона
atmSessionMaksim1.ATMOperation(actions: .userToppingUpPhoneAccount(phone: "+79273919860"), payment: .card(amount: 800))
atmSessionMaksim1.ATMOperation(actions: .userToppingUpPhoneAccount(phone: "+79273919860"), payment: .deposit(amount: 700))

////// Проверка пополнения номера телефона
atmSessionMaksim1.ATMOperation(actions: .userToppingUpPhoneAccount(phone: maksim.userPhone), payment: .cash(amount: 400))
atmSessionMaksim1.ATMOperation(actions: .userToppingUpPhoneAccount(phone: maksim.userPhone), payment: .card(amount: 200))
