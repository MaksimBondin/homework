// 1. Создайте перечисление для ошибок. Добавьте в него 3 кейса:

//enum ListError: Error {
//
//    case error400
//    case error404
//    case error500
//}
//
//var error400: Bool = false
//var error404: Bool = false
//var error500: Bool = true
//
//do {
//
//    if error400 {
//        throw ListError.error400
//    }
//
//    if error404 {
//        throw ListError.error404
//    }
//
//    if error500 {
//        throw ListError.error500
//    }
//
//} catch ListError.error400 {
//    print("Ошибка 400")
//} catch ListError.error404 {
//    print("Ошибка 404")
//} catch ListError.error500 {
//    print("Ошибка 500")
//}



/// 2. Теперь добавьте проверку переменных в генерирующую функцию и обрабатывайте её
///
/// Не уверен, что правильно сделал, т.к  плохо понял эту тему.

//enum ListError: Error {
//
//    case error400
//    case error404
//    case error500
//}
//
//var error400: Bool = false
//var error404: Bool = false
//var error500: Bool = true
//
//func ListError1() throws {
//
//    if error400 {
//        throw ListError.error400
//    }
//
//    if error404 {
//        throw ListError.error404
//    }
//
//    if error500 {
//        throw ListError.error500
//    }
//}
//
//do {
//    try ListError1()
//
//} catch ListError.error400 {
//    print("Ошибка 400")
//} catch ListError.error404 {
//    print("Ошибка 404")
//} catch ListError.error500 {
//    print("Ошибка 500")
//}
//

// 3. Напишите функцию, которая будет принимать на вход два разных типа и проверять: если типы входных значений одинаковые, то вывести сообщение “Yes”, в противном случае — “No”.

func YesNo <T,E> ( a: T, b: E ) {
    
    if type(of: a) == type(of: b) {
        print("Yes")
    }else{
        print("No")
    }
}

YesNo(a: 1, b: 1.2)



// 4.

enum throwYesNo: Error {
    
    case Yes
    case No
}

func YesOrNo <T,E>( a: T, b: E) throws {
    
    if type(of: a) == type(of: b) {
        throw throwYesNo.Yes
    }else{
        throw throwYesNo.No
    }
}

do {
    try YesOrNo(a: 2, b: 2)
    
}catch throwYesNo.Yes {
    print("Одинаковые")
    
}catch throwYesNo.No {
    print("Разные")
}


// 5. Напишите функцию, которая принимает на вход два любых значения и сравнивает их при помощи оператора равенства ==.


func comparison <T: Equatable> ( One: T, Two: T ) -> Bool {
    
    if One == Two {
        print("Равны")
    }
    
    if One != Two {
        print("Не равны")
    }
    
    return One == Two
}

comparison(One: "1", Two: "2")
