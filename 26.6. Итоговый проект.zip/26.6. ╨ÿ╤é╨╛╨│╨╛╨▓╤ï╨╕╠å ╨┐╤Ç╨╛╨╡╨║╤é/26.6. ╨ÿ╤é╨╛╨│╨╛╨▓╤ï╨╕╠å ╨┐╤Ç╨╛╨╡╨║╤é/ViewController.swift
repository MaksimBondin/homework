//
//  ViewController.swift
//  26.6. Итоговый проект
//
//  Created by macbook on 17.05.2024.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var myImage: UIImageView!
    
    //   let imageOne = UIImage(named: "dark")
    
    @IBOutlet weak var myImageSecond: UIImageView!
    
    //   let imageSecond = UIImage(named: "light")
    
    
    @IBOutlet weak var mySwitch: UISwitch!
    
    
    
    
    
    @IBOutlet weak var labelOnOff: UILabel!
    
   
    
    
    @IBOutlet weak var imageTest: UIImageView!
    
    
    //  @IBOutlet weak var myControl: UISegmentedControl!
    
    let usedDefaults = UserDefaults.standard
    
    let onOfKey = "onOfKey"
    
    // SegmentControll
    
    var segmentControll = UISegmentedControl()
    var menuArray = ["Светлая", "Темная"]
    
    var menuOne = UIImage(named: "sun20х20")
    var menuTwo = UIImage(named: "moon20х20")
    
    // для imageView
    
    var imageView = UIImageView()
    var imageArray = [UIImage(named: "light"), UIImage(named: "dark")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        checkSwitch()
        
        // Для segment controll
        self.segmentControll = UISegmentedControl(items: [menuOne as Any, menuTwo as Any])
        self.segmentControll.frame = CGRect(x: 100, y: 100, width: 200, height: 40)
        self.view.addSubview(self.segmentControll)
        self.segmentControll.addTarget(self, action: #selector(selectedView), for: .valueChanged)
        self.segmentControll.backgroundColor = .white
        
        // Для imageView
        
        self.imageView.frame = CGRect(x: 100, y: 170, width: 200, height: 200)
        
        //self.imageView.image = self.imageArray[0]
        self.view.addSubview(self.imageView)
        
    }
    
    @objc func selectedView(target: UISegmentedControl) {
        
        if target == self.segmentControll {
            let segmentIndex = target.selectedSegmentIndex
            
            
            if segmentIndex == 0 {
                
                usedDefaults.set(true, forKey: onOfKey)
                view.backgroundColor = .white
                imageTest.image = UIImage(named: "light")
                mySwitch.isOn = true

                labelOnOff.text = "Темная"
                labelOnOff.textColor = .black
                imageView.image = UIImage(named: "light")
                
                
                
            } else if segmentIndex == 1 {
                
                
                usedDefaults.set(false, forKey: onOfKey)
                view.backgroundColor = .black
                
                segmentControll.backgroundColor = .white
                imageTest.image = UIImage(named: "dark")
                mySwitch.isOn = false
                labelOnOff.text = "Светлая"
                labelOnOff.textColor = .white
                imageView.image = UIImage(named: "dark")
                
            
                
                
            }
        }
        
        
    }
    
    
    
    func checkSwitch() {
        
        if(usedDefaults.bool(forKey: onOfKey))  {
            
            mySwitch.setOn(true, animated: false)
            labelOnOff.text = "Темная"
            labelOnOff.textColor = .black
            view.backgroundColor = .white
            segmentControll.selectedSegmentIndex = 0
            imageTest.image = UIImage(named: "light")
            imageView.image = UIImage(named: "light")
            
            
            
        } else {
            
            mySwitch.setOn(false, animated: false)
            labelOnOff.text = "Светлая"
            labelOnOff.textColor = .white
            view.backgroundColor = .black
            segmentControll.selectedSegmentIndex = 1
            imageTest.image = UIImage(named: "dark")
            imageView.image = UIImage(named: "dark")
            
            
        }
        
    }
    
    // Для Светлой темы
    @IBAction func mySwitchAction(_ sender: UISwitch) {
        
        
        if (mySwitch.isOn) {
            
            usedDefaults.set(true, forKey: onOfKey)
            labelOnOff.text = "Темная"
            labelOnOff.textColor = .black
            view.backgroundColor = .white
            imageTest.image = UIImage(named: "light")
            imageView.image = UIImage(named: "light")
            segmentControll.selectedSegmentIndex = 0
            
            
        }

            else {

                    usedDefaults.set(false, forKey: onOfKey)
                    labelOnOff.text = "Светлая"
                    labelOnOff.textColor = .white
                    view.backgroundColor = .black
                    imageTest.image = UIImage(named: "dark")
                    imageView.image = UIImage(named: "dark")
                    segmentControll.selectedSegmentIndex = 1


                }

        
    }
  
}
