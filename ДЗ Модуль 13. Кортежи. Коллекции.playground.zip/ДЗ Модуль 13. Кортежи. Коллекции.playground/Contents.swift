import UIKit

// 1 Создай кортеж для двух человек с одинаковыми типами данных и параметрами. При том одни значения доставай по индексу, а другие — по параметру.

var humanOne = (name: "Алексей", age: 24)

humanOne.0
humanOne.1

var humanTwo = (name: "Сергей", age: 33)

humanTwo.name
humanTwo.age


// 2 Создай массив «дни в месяцах»

let daysInMonths = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

for (month, day) in daysInMonths.enumerated() {
    
    print("Кол-во дней в \(month + 1) месяце: \(day)")
}


// используй еще один массив с именами месяцев чтобы вывести название месяца + количество дней

let months = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"]

for i in 0..<months.count {
    
    print("Кол-во дней в месяце \(months[i]): \(daysInMonths[i]) ")
}

// сделай тоже самое, но используя массив кортежей с параметрами (имя месяца, количество дней)

let monthDays: [(String, Int)] = [ ("Январь", 31), ("Февраль", 29), ("Март", 31), ("Апрель", 30), ("Май", 31),("Июнь", 30), ("Июль", 31), ("Август", 31), ("Сентябрь", 30), ("Октябрь", 31), ("Ноябрь", 30), ("Декабрь", 31) ]

for i in 0..<monthDays.count {
    
    print("Кол-во дней в месяце \(months[i]): \(daysInMonths[i]) ")
}



// 3 Создай словарь, как журнал студентов, где имя и фамилия студента это ключ, а оценка за экзамен — значение


var students: [String: Int] = ["Антон": 5, "Дмитрий": 3, "Виктория": 5, "Евгений": 2]

// Повысь студенту оценку за экзамен
students["Дмитрий"] = 4

print(students)

for (key, value) in students {
    
    if value >= 3 {
        print("\(key), ваша оценка: \(value), вы сдали экзамен!")
    } else {
        
        print("\(key), ваша оценка: \(value), вы не сдали экзамен!")
        
    }
}

// Не знал как делать, нашел пример в интернете

func averageScore(students: [String: Int]) -> Double {
    
    let total = students.values.reduce(0, +)
    
    let count = students.count
    
    return count > 0 ? Double(total) / Double(count) : 0.0
    
}

let average = averageScore(students: students)
print("Средний балл: \(average)")


// Добавь еще несколько студентов
students["Михаил"] = 3
print(students)

// Удали одного студента — он отчислен
students["Евгений"] = nil
print(students)

// Удали одного студента — он отчислен
students.removeValue(forKey: "Михаил")
print(students)
