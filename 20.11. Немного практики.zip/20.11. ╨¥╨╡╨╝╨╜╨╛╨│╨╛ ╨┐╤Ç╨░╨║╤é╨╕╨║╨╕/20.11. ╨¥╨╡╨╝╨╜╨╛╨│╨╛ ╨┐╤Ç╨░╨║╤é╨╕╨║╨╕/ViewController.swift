//
//  ViewController.swift
//  20.11. Немного практики
//
//  Created by macbook on 04.04.2024.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    
    @IBOutlet weak var collectionViewOne: UICollectionView!
    
    @IBOutlet weak var collectionViewTwo: UICollectionView!
    
    
    let arrayTemperature = ["temp.green","temp.blackGreen","temp.lightYellow","temp.darkYellow","temp.orange","temp.red"]
    
    let arraySmiles = ["favorite","nice","routine","notPleasant","bad","hate"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionViewOne.delegate = self
        collectionViewOne.dataSource = self
        
        collectionViewTwo.delegate = self
        collectionViewTwo.dataSource = self
        
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let vc = storyboard?.instantiateViewController(withIdentifier: "ShowImageVC") as? ShowImageVC else { return }
        
        var currentSelectedImage: String!
        
        if collectionView == collectionViewOne {
            currentSelectedImage = arrayTemperature[indexPath.row]
        }
        
        if collectionView == collectionViewTwo {
            currentSelectedImage = arraySmiles[indexPath.row]
        }
        
        vc.setImageName(name: currentSelectedImage)
        present(vc, animated: true , completion: nil)
        
    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if collectionView == collectionViewOne {
            
            return arrayTemperature.count
        }
        
        if collectionView == collectionViewTwo {
            
            return arraySmiles.count
        }
        return 0
    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == collectionViewOne {
            
            if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellOne", for: indexPath) as? Cell {
                
                let imagName = arrayTemperature[indexPath.row]
                cell.setTemperatureImage(tempName: imagName)
                return cell
            }
            
        }
        
        if collectionView == collectionViewTwo {
            
            if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellTwo", for: indexPath) as? Cell {
                
                let imagName = arraySmiles[indexPath.row]
                cell.setSmileImage(smileName: imagName)
                return cell
            }
        }
        
        return UICollectionViewCell()
    }

}

