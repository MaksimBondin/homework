//
//  TableViewController.swift
//  24.3. MVC ToDoList
//
//  Created by macbook on 06.05.2024.
//

import UIKit

class TableViewController: UITableViewController {
    
    let model = Model()
    
    let customCell = CustomCell()
    
    var alert = UIAlertController()
    
    @IBOutlet weak var addButton: UIBarButtonItem!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        tableView.separatorColor = .gray
        
        title = "My List"
        tableView.reloadData()
        
        
    }
    
    // Для вывода и отображения CustomCell
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return model.toDoItems.count
    }
    
    override func tableView( _ tableView: UITableView, cellForRowAt IndexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: IndexPath) as! CustomCell
        
                cell.delegate = self
        
        let currentItem = model.toDoItems[IndexPath.row]
        cell.customCellTextLabel?.text = currentItem.string
        cell.accessoryType = currentItem.completed ? .checkmark : .none
        
        
        return cell
        
    }
    
    // Для статуса(голочки)
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if model.changeState(at: indexPath.row) == true {
            tableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
        
        } else {
            
            tableView.cellForRow(at: indexPath)?.accessoryType = .none
            
        }
        
    }
    
    // Для кнопки addButtonAction (plus)
    
    @objc func alertTextFieldDidChange(_ sender: UITextField) {

        guard let senderText = sender.text, alert.actions.indices.contains(1) else {
            return
        }

        let action = alert.actions[1]
        action.isEnabled = senderText.count > 0
    }
    
    
    @IBAction func addButtonAction(_ sender: Any) {
        
        alert = UIAlertController(title: "Добавить заметку", message: nil, preferredStyle: .alert)
        
        alert.addTextField() {
            
            (textField: UITextField) in
            textField.placeholder = "Введите текст"
            textField.addTarget(self, action: #selector(self.alertTextFieldDidChange(_:)), for: .editingChanged)
            
            
        }
        
        
        let createAlertAction = UIAlertAction(title: "Добавить", style: .default) {
            
            (createAlert) in
            
            guard let unwrTextFieldValue = self.alert.textFields?[0].text
                    
            else{
                
                return
            }
            
            self.model.addItem(itemName: unwrTextFieldValue)
            self.tableView.reloadData()
            
        }
        
        let cancelAlertAction = UIAlertAction(title: "Назад", style: .cancel, handler: nil)
        
        alert.addAction(cancelAlertAction)
        alert.addAction(createAlertAction)
        present(alert, animated: true, completion: nil)
        createAlertAction.isEnabled = false
        
    }
    

// Для кнопки customCellEditButton (pencil)
    
    
    func editCellContent(indexPath: IndexPath) {

        let cell = tableView(tableView, cellForRowAt: indexPath) as! CustomCell
        
        alert = UIAlertController(title: "Редактировать", message: nil, preferredStyle: .alert)

        alert.addTextField(configurationHandler: { (textField) -> Void in
            textField.addTarget(self, action: #selector(self.alertTextFieldDidChange(_:)), for: .editingChanged)
            textField.text = cell.customCellTextLabel.text
            
        })
        
        let cancelAlertAction = UIAlertAction(title: "Назад", style: .cancel, handler: nil)

        let editAlertAction = UIAlertAction(title: "Готово", style: .default) { (createAlert) in
            
            guard let textFields = self.alert.textFields, textFields.count > 0 else{
                return
            }
            
            guard let textValue = self.alert.textFields?[0].text else {
                return
            }
            
            self.model.editItem(at: indexPath.row, with: textValue)
            
            self.tableView.reloadData()

        }
        
        alert.addAction(cancelAlertAction)
        alert.addAction(editAlertAction)
        present(alert, animated: true, completion: nil)
        
    }


}

// Для кнопки удалить и редактировать

extension TableViewController: CustomCellDelegate {
    
    
    func editCell(cell: CustomCell) {

        let indexPath = tableView.indexPath(for: cell)

        guard let unwrIndexPath = indexPath else {
            return
        }

        self.editCellContent(indexPath: unwrIndexPath)

    }
    
    func deleteCell(cell: CustomCell) {
        
        let indexPath = tableView.indexPath(for: cell)
        
        guard let unwrIndexPath = indexPath else {
            return
        }
        
        model.removeItem(at: unwrIndexPath.row)
        tableView.reloadData()
    }
    

}

