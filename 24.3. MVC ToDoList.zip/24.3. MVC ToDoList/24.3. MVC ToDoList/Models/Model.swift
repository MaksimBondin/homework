//
//  Model.swift
//  24.3. MVC ToDoList
//
//  Created by macbook on 06.05.2024.
//

import Foundation
import UIKit

class Item {
    
    var string: String
    var completed: Bool
    
    
    init(string: String, completed: Bool) {
        self.string = string
        self.completed = completed
        
    }
}
    
    class Model {
        
        var editButtonClicked: Bool = false
        
        var toDoItems: [Item] = [Item(string: "Молоко", completed: false), Item(string: "Хлеб", completed: true), Item(string: "Чай", completed: false)]
        
        func addItem(itemName: String, isCompleted: Bool = false) {
            
            toDoItems.append(Item(string: itemName, completed: isCompleted))
            
        }
        
        // Кнопка добавить
        func removeItem(at index: Int) {
            
            toDoItems.remove(at: index)
        }
        
        // Кнопка редактировать
        func editItem(at index: Int, with string: String) {
            
            toDoItems[index].string = string
        }
        
        // Статус (галочка)
        func changeState(at item: Int) -> Bool {
            toDoItems[item].completed = !toDoItems[item].completed
        
        return toDoItems[item].completed
        }
        
    }
    
