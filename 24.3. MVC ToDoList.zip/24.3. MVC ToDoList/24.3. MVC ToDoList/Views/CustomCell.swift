//
//  CustomCell.swift
//  24.3. MVC ToDoList
//
//  Created by macbook on 06.05.2024.
//

import UIKit


protocol CustomCellDelegate {
    func editCell(cell: CustomCell)
    func deleteCell(cell: CustomCell)
}

class CustomCell: UITableViewCell {
    
    var delegate: CustomCellDelegate?
   
    @IBOutlet weak var customCellTextLabel: UILabel!
    
    
    @IBOutlet weak var customCellDeleteButton: UIButton!
    
    // Кнопка добавить
    
    @IBAction func customCellDeleteButtonAction(_ sender: UIButton) {
        
        delegate?.deleteCell(cell: self)
        
        print("Del")
        
    }
    // Кнопка редактировать
    
    @IBAction func customCellEditButton(_ sender: UIButton) {
        
        delegate?.editCell(cell: self)
        
    }
    
    
}
